declare module './*.js';
